#!/bin/bash
set -e

#
# This is used by SoCks to modify the base installation of the BusyBox RAMFS
#
# $1: Install root directory
#

install_root=$1
printf "Argument install_root is: $install_root\n"

#
# Do not modify anything before this line!
#

# Add your commands here!
