#!/bin/bash

#
# This is used by SoCks to conclude the creation of the Alpine Linux RAMFS
#
# $1: Target architecture
# $2: Alpine Linux repositories
# $3: Install root directory
#

target_arch=$1
printf "Argument target_arch is: $target_arch\n"
alpine_repos=$2
printf "Argument alpine_repos is: $alpine_repos\n"
install_root=$3
printf "Argument install_root is: $install_root\n"

#
# Do not modify anything before this line!
#

# Add services
chroot $install_root /bin/sh -c "rc-update add devfs sysinit"
chroot $install_root /bin/sh -c "rc-update add dmesg sysinit"
chroot $install_root /bin/sh -c "rc-update add mdev sysinit"
chroot $install_root /bin/sh -c "rc-update add hwdrivers sysinit"

chroot $install_root /bin/sh -c "rc-update add modules boot"
chroot $install_root /bin/sh -c "rc-update add sysctl boot"
chroot $install_root /bin/sh -c "rc-update add hostname boot"
chroot $install_root /bin/sh -c "rc-update add bootmisc boot"
chroot $install_root /bin/sh -c "rc-update add syslog boot"
chroot $install_root /bin/sh -c "rc-update add swclock boot"
chroot $install_root /bin/sh -c "rc-update add networking boot"

chroot $install_root /bin/sh -c "rc-update add mount-ro shutdown"
chroot $install_root /bin/sh -c "rc-update add killprocs shutdown"
chroot $install_root /bin/sh -c "rc-update add savecache shutdown"

chroot $install_root /bin/sh -c "rc-update add firstboot default"

# Create a symlink to init so that the kernel executes it automatically
chroot $install_root /bin/sh -c "ln -s /sbin/init /init"

# Enable login on UART
cat <<EOF >> "$install_root/etc/inittab"
# Enable login on alternative console
ttyPS0::respawn:/sbin/getty -L 115200 ttyPS0 vt100
EOF

# Enable sudo for members of group wheel
sed -i "s&# %wheel ALL=(ALL:ALL) ALL&%wheel ALL=(ALL:ALL) ALL&g" "$install_root/etc/sudoers"
