#!/bin/bash
set -e

#
# This is used by SoCks to modify the base Alpine Linux RootFS
#
# $1: Target architecture
# $2: Alpine Linux repositories
# $3: Install root directory
#

target_arch=$1
printf "Argument target_arch is: $target_arch\n"
alpine_repos=$2
printf "Argument alpine_repos is: $alpine_repos\n"
install_root=$3
printf "Argument install_root is: $install_root\n"

#
# Do not modify anything before this line!
#

# Add your commands here!
