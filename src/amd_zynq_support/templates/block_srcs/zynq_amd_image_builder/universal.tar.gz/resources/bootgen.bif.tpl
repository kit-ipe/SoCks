the_ROM_image:
{
	[bootloader] <FSBL_PATH>
	<PLBIT_PATH>
	<SSBL_PATH>
	[load=0x100000] <DTB_PATH>
}
